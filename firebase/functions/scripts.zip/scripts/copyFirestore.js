// import admin from 'firebase-admin';
// import { fileURLToPath } from 'url';
// import path from 'path';
//
// // Get the directory of the current module
// const __filename = fileURLToPath(import.meta.url);
// const __dirname = path.dirname(__filename);
//
// // Initialize Firebase Admin SDK for the old project
// const appOld = admin.initializeApp({
//   credential: admin.credential.cert(path.join(__dirname, './resources/serviceAccountKeyOld.json')),
//   databaseURL: 'https://coverlabs-io.firebaseio.com',
// }, 'appOld');
//
// const dbOld = admin.firestore(appOld);
//
// // Initialize Firebase Admin SDK for the new project
// const appNew = admin.initializeApp({
//   credential: admin.credential.cert(path.join(__dirname, './resources/serviceAccountKeyNew.json')),
//   databaseURL: 'https://coverlabs-app.firebaseio.com',
// }, 'appNew');
//
// const dbNew = admin.firestore(appNew);
//
// async function copyDocument(srcCollection, destCollection, docId) {
//   try {
//     const docRefOld = dbOld.collection(srcCollection).doc(docId);
//     const docRefNew = dbNew.collection(destCollection).doc(docId);
//
//     const docSnapshot = await docRefOld.get();
//     if (!docSnapshot.exists) {
//       console.log(`Document ${docId} does not exist in ${srcCollection}.`);
//       return;
//     }
//
//     // Copy the document data
//     const data = docSnapshot.data();
//     await docRefNew.set(data);
//     console.log(`Copied document ${docId} to ${destCollection}.`);
//
//     // Copy nested collections
//     const subCollections = await docRefOld.listCollections();
//     for (const subCollection of subCollections) {
//       const subCollectionName = subCollection.id;
//       console.log(`Copying nested collection ${subCollectionName} for document ${docId}...`);
//       await copyCollection(
//         `${srcCollection}/${docId}/${subCollectionName}`,
//         `${destCollection}/${docId}/${subCollectionName}`
//       );
//     }
//   } catch (error) {
//     console.error(`Error copying document ${docId}:`, error);
//   }
// }
//
// async function copyCollection(srcCollection, destCollection) {
//   try {
//     console.log(`Fetching documents from collection ${srcCollection}...`);
//     const snapshot = await dbOld.collection(srcCollection).get();
//
//     if (snapshot.empty) {
//       console.log(`No documents found in ${srcCollection}.`);
//       return;
//     }
//
//     console.log(`Copying ${snapshot.size} documents from ${srcCollection}...`);
//
//     for (const doc of snapshot.docs) {
//       const docId = doc.id;
//       console.log(`Found document ${docId}.`);
//       await copyDocument(srcCollection, destCollection, docId);
//     }
//   } catch (error) {
//     console.error(`Error copying collection ${srcCollection}:`, error);
//   }
// }
//
// async function copyFirestore() {
//   try {
//     // Define the collection to copy
//     // const collectionName = 'resources'; // Replace with your collection name
//     const collectionName = 'resources'; // Replace with your collection name
//
//     console.log(`Starting to copy collection: ${collectionName}`);
//     await copyCollection(collectionName, collectionName);
//
//     console.log('Firestore copy complete.');
//   } catch (error) {
//     console.error('Error copying Firestore data:', error);
//   }
// }
//
// copyFirestore();
