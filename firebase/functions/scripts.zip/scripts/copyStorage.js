// const admin = require('firebase-admin');
// const { Storage } = require('@google-cloud/storage');
// const path = require('path');
// const fs = require('fs-extra');
// const os = require('os');
// const { fileURLToPath } = require('url');
//
// // Get the directory of the current module
// const __filename = fileURLToPath(__filename);
// const __dirname = path.dirname(__filename);
//
// // Initialize Firebase Admin SDK for the old project
// const appOld = admin.initializeApp({
//   credential: admin.credential.cert(path.join(__dirname, './resources/serviceAccountKeyOld.json')),
//   storageBucket: 'coverlabs-io.appspot.com',
// }, 'appOld');
//
// const storageOld = admin.storage(appOld).bucket();
//
// // Initialize Firebase Admin SDK for the new project
// const appNew = admin.initializeApp({
//   credential: admin.credential.cert(path.join(__dirname, './resources/serviceAccountKeyNew.json')),
//   storageBucket: 'coverlabs-app.appspot.com',
// }, 'appNew');
//
// const storageNew = admin.storage(appNew).bucket();
//
// async function copyFiles() {
//   try {
//     // List all files in the old bucket
//     const [files] = await storageOld.getFiles();
//     console.log(`Found ${files.length} files in the old bucket.`);
//
//     for (const file of files) {
//       const fileName = file.name;
//
//       // Skip directories
//       if (fileName.endsWith('/')) {
//         console.log(`Skipping directory: ${fileName}`);
//         continue;
//       }
//
//       const tempFilePath = path.join(os.tmpdir(), fileName);
//       const tempFileDir = path.dirname(tempFilePath);
//
//       // Log detailed information
//       console.log(`Processing file: ${fileName}`);
//       console.log(`Temp file path: ${tempFilePath}`);
//       console.log(`Temp file directory: ${tempFileDir}`);
//
//       // Ensure that the directory exists
//       if (!await fs.pathExists(tempFileDir)) {
//         console.log(`Creating directory: ${tempFileDir}`);
//         await fs.ensureDir(tempFileDir);
//       }
//
//       // Download the file from the old bucket
//       console.log(`Downloading ${fileName}...`);
//       await file.download({ destination: tempFilePath });
//       console.log(`File downloaded to ${tempFilePath}`);
//
//       // Upload the file to the new bucket
//       console.log(`Uploading ${fileName} to new bucket...`);
//       await storageNew.upload(tempFilePath, { destination: fileName });
//       console.log(`File uploaded to new bucket`);
//
//       // Clean up the temporary file
//       console.log(`Cleaning up temporary file: ${tempFilePath}`);
//       await fs.unlink(tempFilePath);
//       console.log(`${fileName} copied successfully.`);
//     }
//   } catch (error) {
//     console.error('Error copying files:', error);
//   }
// }
//
// copyFiles();
